#!/usr/bin/env python3
"""Insert Google AdSense script right after <head> in every HTML file under /workspace.
Idempotent: skips files that already contain the AdSense client id."""
import os
import re

ADSENSE_ID = "ca-pub-3625422078884598"
ADSENSE_BLOCK = (
    "<!-- Google AdSense -->\n"
    '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3625422078884598"\n'
    '     crossorigin="anonymous"></script>\n'
)

ROOT = "/workspace"
# Exclude read-only / archive / scratch dirs
EXCLUDE_DIRS = {".trae-html-share-packages", ".uploads"}

modified = []
skipped = []
no_head = []

for dirpath, dirnames, filenames in os.walk(ROOT):
    # prune excluded dirs in-place
    dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
    for fn in filenames:
        if not fn.endswith(".html"):
            continue
        fp = os.path.join(dirpath, fn)
        try:
            with open(fp, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            print(f"ERROR reading {fp}: {e}")
            continue

        if ADSENSE_ID in content:
            skipped.append(fp)
            continue

        # Insert right after the first <head> tag (allow attributes on head tag)
        match = re.search(r"<head[^>]*>", content)
        if not match:
            no_head.append(fp)
            continue

        insert_at = match.end()
        # Place on its own line right after the <head...> tag
        new_content = content[:insert_at] + "\n" + ADSENSE_BLOCK + content[insert_at:]
        # Collapse the extra blank line if <head> was followed by newline
        new_content = new_content.replace(">\n\n" + ADSENSE_BLOCK, ">\n" + ADSENSE_BLOCK, 1)

        with open(fp, "w", encoding="utf-8") as f:
            f.write(new_content)
        modified.append(fp)

print(f"\nModified: {len(modified)} files")
print(f"Skipped (already has AdSense): {len(skipped)} files")
print(f"No <head> found: {len(no_head)} files")
if no_head:
    for f in no_head:
        print(f"  NO HEAD: {f}")
